"use client"

import { useEffect, useState } from "react"
import { Scanner } from "@yudiel/react-qr-scanner"

type Seat = {
  id: number
  rad: number | null
  cislo: number | null
  stol: number | null
  stolicka: number | null
  typMiesta: string
  status: "FREE" | "SOLD" | "CHECKED"
}

type TicketInfo = {
  ticketId: number
  ticketCode: string
  nazov: string
  datumCas: string
  seat: string
  name: string
}

export default function ScanClient({
  terminId
}: {
  terminId: number
}) {

  const [seats, setSeats] = useState<Seat[]>([])
  const [hallName, setHallName] = useState("")
  const [ticket, setTicket] = useState<TicketInfo | null>(null)
  const [status, setStatus] = useState("")
  const [manualCode, setManualCode] = useState("")

  async function loadSeats() {

    if (!terminId) return

    const res = await fetch("/api/scan/hall", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ terminId })
    })

    if (!res.ok) return

    const data = await res.json()

    setSeats(data.seats)
    setHallName(data.hallName)

  }

  useEffect(() => {

    if (!terminId) return

    const fetchSeats = async () => {
        await loadSeats()
    }

    fetchSeats()

    }, [terminId])

  useEffect(() => {

    const eventSource = new EventSource("/api/scan/events")

    eventSource.onmessage = async () => {
      await loadSeats()
    }

    return () => eventSource.close()

  }, [])

  async function verifyTicket(code: string) {

    code = code.trim()

    const res = await fetch("/api/ticket/verify", {

      method: "POST",

      headers: {
        "Content-Type": "application/json"
      },

      body: JSON.stringify({
        ticketCode: code,
        terminId
      })

    })

    let data

    try {
      data = await res.json()
    } catch {
      setStatus("INVALID")
      setTicket(null)
      return
    }

    setStatus(data.status)

    if (data.ticketId) {

      setTicket({
        ticketId: data.ticketId,
        ticketCode: data.ticketCode,
        nazov: data.nazov,
        datumCas: data.datumCas,
        seat: data.seat,
        name: data.name
      })

    } else {

      setTicket(null)

    }

    setManualCode("")

  }

  async function checkin() {

    if (!ticket) return

    const res = await fetch("/api/ticket/checkin", {

      method: "POST",

      headers: {
        "Content-Type": "application/json"
      },

      body: JSON.stringify({
        ticketId: ticket.ticketId
      })

    })

    const data = await res.json()

    if (data.status === "CHECKED_IN") {

      setStatus("CHECKED_IN")

      setTimeout(() => {
        setTicket(null)
        setStatus("")
      }, 1500)

    }

  }

  const capacity = seats.length
  const sold = seats.filter(s => s.status !== "FREE").length
  const checked = seats.filter(s => s.status === "CHECKED").length
  const missing = sold - checked

  const isRowLayout = hallName === "Veľká sála"

  const groupedSeats: Record<string, Seat[]> = {}

  seats.forEach(seat => {

    let key = ""

    if (isRowLayout) {
      key = `row-${seat.rad}`
    } else {
      key = `table-${seat.stol}`
    }

    if (!groupedSeats[key]) groupedSeats[key] = []

    groupedSeats[key].push(seat)

  })

  function renderSeat(seat: Seat) {

    let color = "#4CAF50"

    if (seat.status === "SOLD") color = "#f44336"
    if (seat.status === "CHECKED") color = "#2196F3"

    return (

      <div
        key={seat.id}
        style={{
          width: "36px",
          height: "36px",
          margin: "4px",
          backgroundColor: color,
          borderRadius: "6px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "white",
          fontSize: "12px"
        }}
      >
        {seat.typMiesta === "ROW_SEAT"
          ? seat.cislo
          : seat.stolicka}
      </div>

    )

  }

  return (

    <div style={{ padding: 40 }}>

      <h1>Skenovanie vstupeniek</h1>

      <Scanner
        onScan={(codes) => {

          if (!codes?.length) return

          const value = codes[0].rawValue

          verifyTicket(value)

        }}
      />

      <div style={{ marginTop: 20 }}>

        <input
          placeholder="Zadaj kód vstupenky"
          value={manualCode}
          onChange={(e) => setManualCode(e.target.value)}
        />

        <button
          onClick={() => verifyTicket(manualCode)}
        >
          Overiť
        </button>

      </div>

      {status && (
        <div style={{ marginTop: 20, fontSize: 20 }}>
          Status: {status}
        </div>
      )}

      {ticket && (

        <div style={{ marginTop: 30 }}>

          <h3>{ticket.nazov}</h3>

          <p>{new Date(ticket.datumCas).toLocaleString()}</p>

          <p>{ticket.seat}</p>

          <p>{ticket.name}</p>

          <button
            onClick={checkin}
            style={{
              marginTop: 20,
              padding: "10px 20px",
              fontSize: 18
            }}
          >
            Povoliť vstup
          </button>

        </div>

      )}

      <div style={{ marginTop: 40 }}>

        <b>Kapacita:</b> {capacity} <br/>
        <b>Predané:</b> {sold} <br/>
        <b>Prišlo:</b> {checked} <br/>
        <b>Chýba:</b> {missing}

      </div>

      <h2 style={{ marginTop: 40 }}>
        Mapa sály ({hallName})
      </h2>

      {Object.keys(groupedSeats).map(key => {

        const firstSeat = groupedSeats[key][0]

        return (

          <div key={key} style={{ marginBottom: "20px" }}>

            <div style={{ fontWeight: "bold", marginBottom: 6 }}>

              {isRowLayout
                ? `Rad ${firstSeat.rad}`
                : `Stôl ${firstSeat.stol}`}

            </div>

            <div style={{ display: "flex", flexWrap: "wrap" }}>
              {groupedSeats[key].map(seat => renderSeat(seat))}
            </div>

          </div>

        )

      })}

    </div>

  )

}