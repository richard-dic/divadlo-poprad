import ScanClient from "./ScanClient"
import { requireRole } from "@/lib/requireRole"

export default async function Page({
  params
}: {
  params: Promise<{ terminId: string }>
}) {
  await requireRole(["ADMIN", "CONTROLLER"])

  const { terminId } = await params

  return <ScanClient terminId={Number(terminId)} />
}