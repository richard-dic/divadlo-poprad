"use client"

import { useState } from "react"
import QRScanner from "@/components/QRScanner"

type VerifyResult = {
  status: string
  message: string
  ticketId?: number
  ticketCode?: string
  nazov?: string
  datumCas?: string
  seat?: {
    text?: string
    rad?: number
    cislo?: number
    stol?: number
    stolicka?: number
  }
}

export default function KontrolaVstupeniek() {
  const [ticketCode, setTicketCode] = useState("")
  const [terminId, setTerminId] = useState("")
  const [result, setResult] = useState<VerifyResult | null>(null)
  const [loading, setLoading] = useState(false)

  const verifyTicket = async (code?: string) => {
    const finalCode = code ?? ticketCode

    if (!finalCode || !terminId) {
      alert("Zadaj ticket code aj ID termínu.")
      return
    }

    setLoading(true)

    try {
      const res = await fetch("/api/ticket/verify", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          ticketCode: finalCode,
          terminId: Number(terminId)
        })
      })

      const data = await res.json()
      setResult(data)

      if (code) {
        setTicketCode(code)
      }
    } finally {
      setLoading(false)
    }
  }

  const confirmEntry = async () => {
    if (!result?.ticketId || !terminId) {
      return
    }

    setLoading(true)

    try {
      const res = await fetch("/api/ticket/check-in", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          ticketId: result.ticketId,
          terminId: Number(terminId)
        })
      })

      const data = await res.json()
      setResult(data)
    } finally {
      setLoading(false)
    }
  }

  const handleScan = async (code: string) => {
    await verifyTicket(code)
  }

  const statusColor =
    result?.status === "VALID"
      ? "green"
      : result?.status === "USED"
      ? "orange"
      : "red"

  return (
    <div style={{ padding: "40px", maxWidth: "700px" }}>
      <h1>Kontrola vstupeniek</h1>

      <p>Najprv zadaj ID termínu, na ktorý kontroluješ vstupenky.</p>

      <div style={{ marginBottom: "20px" }}>
        <input
          placeholder="ID termínu"
          value={terminId}
          onChange={(e) => setTerminId(e.target.value)}
          style={{ padding: "10px", marginRight: "10px" }}
        />
      </div>

      <h2>QR skener</h2>
      <QRScanner onScan={handleScan} />

      <hr style={{ margin: "30px 0" }} />

      <h2>Manuálne overenie</h2>

      <input
        placeholder="Zadaj ticket code"
        value={ticketCode}
        onChange={(e) => setTicketCode(e.target.value)}
        style={{ padding: "10px", minWidth: "260px" }}
      />

      <button
        onClick={() => verifyTicket()}
        style={{ marginLeft: "10px", padding: "10px 16px" }}
        disabled={loading}
      >
        Overiť
      </button>

      {result && (
        <div style={{ marginTop: "30px", border: "1px solid #ccc", padding: "20px", borderRadius: "10px" }}>
          <h2 style={{ color: statusColor }}>Výsledok: {result.status}</h2>

          <p>{result.message}</p>

          {result.ticketCode && <p>Kód: {result.ticketCode}</p>}
          {result.nazov && <p>Inscenácia: {result.nazov}</p>}
          {result.datumCas && <p>Dátum a čas: {result.datumCas}</p>}
          {result.seat?.text && <p>{result.seat.text}</p>}

          {result.status === "VALID" && (
            <button
              onClick={confirmEntry}
              style={{ marginTop: "15px", padding: "10px 16px" }}
              disabled={loading}
            >
              Povoliť vstup
            </button>
          )}
        </div>
      )}
    </div>
  )
}