import { prisma } from "@/lib/prisma"
import Link from "next/link"
import { requireRole } from "@/lib/requireRole"

export default async function ScanDashboard() {

  await requireRole(["ADMIN", "CONTROLLER"])

  const terminy = await prisma.terminHrania.findMany({

    include: {
      inscenacia: true,
      tickets: true
    },

    orderBy: {
      datumCas: "asc"
    }

  })

  return (

    <div style={{ padding: 40 }}>

      <h1>Kontrola vstupeniek</h1>

      <table>

        <thead>
          <tr>
            <th>Inscenácia</th>
            <th>Dátum</th>
            <th>Predané</th>
            <th>Skontrolované</th>
            <th></th>
          </tr>
        </thead>

        <tbody>

          {terminy.map((t) => {

            const sold = t.tickets.length
            const checked = t.tickets.filter(
              (ticket) => ticket.usedAt
            ).length

            return (

              <tr key={t.id}>

                <td>{t.inscenacia.nazov}</td>

                <td>
                  {new Date(t.datumCas).toLocaleString("sk-SK")}
                </td>

                <td>{sold}</td>

                <td>{checked}</td>

                <td>
                  <Link href={`/scan/${t.id}`}>
                    Skenovať
                  </Link>
                </td>

              </tr>

            )

          })}

        </tbody>

      </table>

    </div>

  )

}