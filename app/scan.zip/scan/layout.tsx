import { requireRole } from "@/lib/requireRole"

export default async function ScanLayout({
  children
}: {
  children: React.ReactNode
}) {

  await requireRole(["ADMIN", "CONTROLLER"])

  return <>{children}</>

}